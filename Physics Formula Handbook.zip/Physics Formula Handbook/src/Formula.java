
public class Formula {
   public void calculate() {
   }
}
