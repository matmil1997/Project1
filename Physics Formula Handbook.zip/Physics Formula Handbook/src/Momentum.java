import java.util.Scanner;

public class Momentum extends Formula {
	public void calculate(){
        System.out.println("This formula is the momentum formula:");
        System.out.println("p=mv");
        System.out.println("Enter values for m & v");
        int p;
        int m1;
        Scanner input = new Scanner(System.in);
        String str = input.nextLine();
        System.out.println("m = " + str);
        m1 = Integer.parseInt(str);
        int v;
        String str1 = input.nextLine();
        v = Integer.parseInt(str1);
        p=m1 * v;
        System.out.println("m= " + m1 + " v= " + v);
        System.out.println("Momentum is " + p + " kg m/s");
        System.out.println("----------------------------------------------------");
        System.out.println("Enter another letter or type Exit to terminate");

	}
}
