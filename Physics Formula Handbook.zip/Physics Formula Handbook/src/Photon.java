import java.util.Scanner;

public class Photon extends Formula{
	public void calculate(){
	System.out.println("This formula is for the Energy of a Photon:");
    System.out.println("E=hf");
    System.out.println("Enter value for f");
    double E2;
    int f=0;
    Scanner input = new Scanner(System.in);
    String str = input.nextLine();
    System.out.println("f = " + str);
    f = Integer.parseInt(str);
    if (f<0){
    	System.out.println("Frequency as we know it cannot be negative");
    } else {
    double hplanck = 6.626E-34;
    E2 = hplanck * f;
    System.out.println("Energy is " + E2 + " Joules");
    System.out.println("----------------------------------------------------");
    System.out.println("Enter another letter or type Exit to terminate");
    }
    

	}

	private double pow(int i, int j) {
		// TODO Auto-generated method stub
		return 0;
	}
}
